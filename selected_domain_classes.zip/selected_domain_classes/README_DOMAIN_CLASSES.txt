Selected files related to Guest/User/Admin domain classes and their direct dependencies.

PRIMARY DOMAIN CLASSES
- models/guest.py   -> Guest
- models/user.py    -> User inherits from Guest
- models/admin.py   -> Admin inherits from User

DIRECT DEPENDENCIES
- models/database.py -> SQLite connection, password hashing, User/Groups/Contact tables
- models/contact.py  -> Contact operations called by User
- models/group.py    -> Group operations called by User

EXCLUDED FROM THIS SET
- main.py / GUI: View + Controller, not uploaded here
- test_phonebook.py: tests, not part of the domain classes
- requirements.txt: dependency list, not part of the domain classes
- README.md: project documentation
