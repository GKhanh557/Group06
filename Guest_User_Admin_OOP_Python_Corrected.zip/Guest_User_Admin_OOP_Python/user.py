"""
user.py

The User class represents someone who has logged in.
User INHERITS from Guest (User "is a" Guest who now has an account) -
this matches the generalization arrow in the Class Diagram.

Notice: User does not repeat register()/login()/view_demo_contacts() -
those are inherited automatically from Guest.
"""

from guest import Guest
from contact import Contact
from group import Group


class User(Guest):

    def __init__(self, user_id, username, email, role="user", is_locked=0):
        self.user_id = user_id
        self.username = username
        self.email = email
        self.role = role
        self.is_locked = is_locked

    # ---- Contacts ----
    def view_contact_list(self):
        """FR5"""
        return Contact.get_all_contacts(self.user_id)

    def search_contact(self, keyword):
        """FR6"""
        return Contact.search_contact(self.user_id, keyword)

    def add_contact(self, full_name, phone_number, email="", address="", note="", group_id=None):
        """FR4"""
        return Contact.add_contact(full_name, phone_number, self.user_id, email, address, note, group_id)

    def edit_contact(self, contact_id, full_name, phone_number, email, address, note, group_id):
        """FR7"""
        return Contact.edit_contact(contact_id, self.user_id, full_name, phone_number, email, address, note, group_id)

    def delete_contact(self, contact_id):
        """FR8"""
        return Contact.delete_contact(contact_id, self.user_id)

    def mark_favorite(self, contact_id):
        """FR10"""
        Contact.toggle_favorite(contact_id, self.user_id)

    def import_contact(self, filepath):
        """FR15"""
        return Contact.import_from_csv(self.user_id, filepath)

    def export_contact(self, filepath):
        """FR16"""
        return Contact.export_to_csv(self.user_id, filepath)

    # ---- Groups ----
    def view_group(self):
        """FR13"""
        return Group.get_all_groups(self.user_id)

    def create_group(self, group_name):
        """FR12"""
        return Group.add_group(group_name, self.user_id)

    def edit_group(self, group_id, new_name):
        """FR14"""
        return Group.edit_group(group_id, self.user_id, new_name)

    def delete_group(self, group_id):
        """FR11"""
        return Group.delete_group(group_id, self.user_id)
