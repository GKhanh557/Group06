# Guest / User / Admin — Corrected Version

This is a **corrected version** of the domain classes originally submitted
(`Guest_User_Admin_OOP_Python.zip`). The class names, inheritance structure
(Guest → User → Admin), and method names are the same — only the **internal
logic** was fixed so the classes actually work with the real database
instead of an in-memory Python list.

## What was fixed and why

| File | Problem in the original version | Fix |
|---|---|---|
| `guest.py` | `Register()`/`Login()` took no parameters and always returned `True`, no matter what was typed. `ViewDemoContacts()` always returned an empty list. | Now `register(username, password, email)` and `login(username, password)` actually check the database, validate the password length, hash passwords, and reject wrong credentials. `view_demo_contacts()` returns 3 real sample contacts. |
| `user.py` | All data (contacts, groups) was stored in a Python list inside the object — lost every time the program closed. `SearchContact()` ignored the keyword and returned everything. `MarkFavorite()` affected *every* contact instead of one. | Now every method reads/writes to the SQLite database (`database.py`), so data is saved permanently. Search actually filters by keyword. Favorite/edit/delete all target one specific contact by ID. |
| `admin.py` | `LockAccount()` / `UnlockAccount()` always returned `True` without changing anything. `ViewSystemStatistics()` always returned zeros. | Now these methods update the real `is_locked` column in the database, and statistics are calculated with real SQL `COUNT()` queries. |
| *(new)* `database.py` | Did not exist in the original submission — this is why nothing could be saved. | Added: creates the 3 tables (User, Groups, Contact) and connects everything together. |

## Why this matters

In the original version, running this small test would **incorrectly pass**
even though locking doesn't really work:

```python
admin.LockAccount()      # always returns True, does nothing real
```

With the fix, the same action actually prevents the locked user from
logging in afterward — which is what the assignment requires (FR18).

## How to test it yourself

```bash
python3 -c "
from database import create_tables
from guest import Guest
from admin import Admin

create_tables()
Guest().register('alice', 'password1', 'alice@example.com')
row, msg = Guest().login('alice', 'password1')
print(msg)   # 'Login successful.'
"
```
