"""
guest.py

The Guest class represents a visitor who has NOT logged in yet.
A Guest can only do 3 things (see the Use Case Diagram):
  1. View a demo (sample) contact list
  2. Register a new account
  3. Login (after registering)
"""

from database import get_connection, hash_password

# A fixed list of sample contacts, used only for the "View Demo Contacts" feature.
# This is NOT read from the database - it is just example data so a Guest can
# see what the contact list looks like before creating an account.
DEMO_CONTACTS = [
    {"full_name": "Nguyen Van Demo", "phone_number": "0900000001", "email": "demo1@example.com"},
    {"full_name": "Tran Thi Demo", "phone_number": "0900000002", "email": "demo2@example.com"},
    {"full_name": "Le Van Demo", "phone_number": "0900000003", "email": "demo3@example.com"},
]


class Guest:
    """Guest is the base class. User will inherit from Guest."""

    def view_demo_contacts(self):
        """FR2: show the fixed sample contact list."""
        return DEMO_CONTACTS

    def register(self, username, password, email):
        """
        FR1: create a new account.
        Returns a tuple (success: bool, message: str)
        """
        username = username.strip()
        password = password.strip()

        if username == "" or password == "":
            return False, "Username and password cannot be empty."

        if len(password) < 6:
            return False, "Password must be at least 6 characters."

        conn = get_connection()
        cursor = conn.cursor()

        # Check if the username is already taken
        cursor.execute("SELECT * FROM User WHERE username = ?", (username,))
        if cursor.fetchone() is not None:
            conn.close()
            return False, "This username already exists."

        # Save the new account (password is hashed, never stored as plain text)
        cursor.execute(
            "INSERT INTO User (username, password, email, role) VALUES (?, ?, ?, 'user')",
            (username, hash_password(password), email),
        )
        new_user_id = cursor.lastrowid

        # Give the new user 4 default groups to start with
        for group_name in ["Personal", "Work", "Family", "Other"]:
            cursor.execute(
                "INSERT INTO Groups (group_name, user_id) VALUES (?, ?)",
                (group_name, new_user_id),
            )

        conn.commit()
        conn.close()
        return True, "Registration successful! You can now log in."

    def login(self, username, password):
        """
        FR3: check username/password and return the account info if correct.
        Returns a tuple (user_row or None, message: str)
        """
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM User WHERE username = ?", (username.strip(),))
        row = cursor.fetchone()
        conn.close()

        if row is None:
            return None, "Incorrect username or password."

        if row["is_locked"] == 1:
            return None, "This account has been locked by the administrator."

        if row["password"] != hash_password(password):
            return None, "Incorrect username or password."

        return row, "Login successful."

    def reset_password(self, username, email, new_password):
        """
        Supports NFR4 (Security): if a user forgets their password, they can
        reset it by confirming their username AND their registered email.
        Returns a tuple (success: bool, message: str)
        """
        new_password = new_password.strip()
        if len(new_password) < 6:
            return False, "New password must be at least 6 characters."

        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT * FROM User WHERE username = ? AND email = ?",
            (username.strip(), email.strip()),
        )
        row = cursor.fetchone()

        if row is None:
            conn.close()
            return False, "Username and registered email do not match."

        cursor.execute(
            "UPDATE User SET password = ? WHERE user_id = ?",
            (hash_password(new_password), row["user_id"]),
        )
        conn.commit()
        conn.close()
        return True, "Password reset successful. You can now log in with your new password."
