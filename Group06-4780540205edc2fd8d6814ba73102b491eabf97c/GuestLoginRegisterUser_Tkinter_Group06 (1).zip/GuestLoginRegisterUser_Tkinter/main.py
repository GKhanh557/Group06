"""
main.py

This is the MAIN PROGRAM. Run it with:  python3 main.py

How this file works (for a beginner):
- We create ONE window (self.root).
- Each "screen" (Guest screen, Login screen, User screen, ...) is just a
  function that clears the window and draws new widgets on it.
- We keep track of "who is using the program right now" in self.current_user
  (it will be None if nobody is logged in yet = Guest).

Architecture note: this program follows MVC.
  - Model  = the classes in the models/ folder (Guest, User, Admin, Contact, Group)
  - View   = the Tkinter widgets created in this file
  - Controller = the button-click functions in this file, which call the Model
                 and then update the View
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog

from models.database import create_tables
from models.guest import Guest
from models.user import User
from models.admin import Admin
from models.contact import Contact
from models.group import Group

WINDOW_WIDTH = 850
WINDOW_HEIGHT = 550


class PhoneBookApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Phone Book Management System")
        self.root.geometry(f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}")

        self.current_user = None       # will hold a User or Admin object once logged in
        self.selected_contact_id = None

        self.show_guest_screen()

    # ------------------------------------------------------------
    # Helper: clear everything currently shown, so we can draw a new screen
    # ------------------------------------------------------------
    def clear_window(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    # ==============================================================
    # SCREEN 1: GUEST (not logged in)  -  FR1, FR2, FR3
    # ==============================================================
    def show_guest_screen(self):
        self.clear_window()
        self.current_user = None

        tk.Label(self.root, text="PHONE BOOK MANAGEMENT SYSTEM",
                 font=("Arial", 18, "bold")).pack(pady=(30, 5))
        tk.Label(self.root, text="You are browsing as Guest", font=("Arial", 11)).pack(pady=(0, 20))

        tk.Button(self.root, text="View Demo Contacts", width=28, height=2,
                  command=self.show_demo_contacts).pack(pady=6)
        tk.Button(self.root, text="Register Account", width=28, height=2,
                  command=self.show_register_screen).pack(pady=6)
        tk.Button(self.root, text="Login", width=28, height=2,
                  command=self.show_login_screen).pack(pady=6)

    def show_demo_contacts(self):
        """FR2: show sample data using a simple table (Treeview)."""
        self.clear_window()
        tk.Label(self.root, text="Demo Contacts (read-only)", font=("Arial", 14, "bold")).pack(pady=10)

        table = ttk.Treeview(self.root, columns=("name", "phone", "email"), show="headings", height=8)
        table.heading("name", text="Full Name")
        table.heading("phone", text="Phone Number")
        table.heading("email", text="Email")
        table.pack(padx=20, pady=10, fill="x")

        for contact in Guest().view_demo_contacts():
            table.insert("", "end", values=(contact["full_name"], contact["phone_number"], contact["email"]))

        tk.Button(self.root, text="Back", command=self.show_guest_screen).pack(pady=10)

    # ==============================================================
    # SCREEN 2: REGISTER  -  FR1
    # ==============================================================
    def show_register_screen(self):
        self.clear_window()
        tk.Label(self.root, text="Register a New Account", font=("Arial", 16, "bold")).pack(pady=20)

        form = tk.Frame(self.root)
        form.pack()

        tk.Label(form, text="Username:").grid(row=0, column=0, sticky="e", padx=5, pady=8)
        username_entry = tk.Entry(form, width=30)
        username_entry.grid(row=0, column=1, pady=8)

        tk.Label(form, text="Password:").grid(row=1, column=0, sticky="e", padx=5, pady=8)
        password_entry = tk.Entry(form, width=30, show="*")
        password_entry.grid(row=1, column=1, pady=8)

        tk.Label(form, text="Email:").grid(row=2, column=0, sticky="e", padx=5, pady=8)
        email_entry = tk.Entry(form, width=30)
        email_entry.grid(row=2, column=1, pady=8)

        def do_register():
            success, message = Guest().register(
                username_entry.get(), password_entry.get(), email_entry.get()
            )
            if success:
                messagebox.showinfo("Success", message)
                self.show_login_screen()
            else:
                messagebox.showerror("Error", message)

        tk.Button(self.root, text="Create Account", width=20, command=do_register).pack(pady=15)
        tk.Button(self.root, text="Back", command=self.show_guest_screen).pack()

    # ==============================================================
    # SCREEN 3: LOGIN  -  FR3
    # ==============================================================
    def show_login_screen(self):
        self.clear_window()
        tk.Label(self.root, text="Login", font=("Arial", 16, "bold")).pack(pady=20)

        form = tk.Frame(self.root)
        form.pack()

        tk.Label(form, text="Username:").grid(row=0, column=0, sticky="e", padx=5, pady=8)
        username_entry = tk.Entry(form, width=30)
        username_entry.grid(row=0, column=1, pady=8)

        tk.Label(form, text="Password:").grid(row=1, column=0, sticky="e", padx=5, pady=8)
        password_entry = tk.Entry(form, width=30, show="*")
        password_entry.grid(row=1, column=1, pady=8)

        def do_login():
            row, message = Guest().login(username_entry.get(), password_entry.get())
            if row is None:
                messagebox.showerror("Login failed", message)
                return

            # Build the correct object: Admin or User, based on the "role" column
            if row["role"] == "admin":
                self.current_user = Admin(row["user_id"], row["username"], row["email"], row["role"])
                self.show_admin_screen()
            else:
                self.current_user = User(row["user_id"], row["username"], row["email"], row["role"])
                self.show_user_screen()

        tk.Button(self.root, text="Login", width=20, command=do_login).pack(pady=15)
        tk.Button(self.root, text="Forgot Password?", command=self.show_forgot_password_screen).pack()
        tk.Button(self.root, text="Back", command=self.show_guest_screen).pack(pady=(10, 0))
        tk.Label(self.root, text="(Default admin account: admin / admin123)",
                 font=("Arial", 8), fg="gray").pack(pady=10)

    # ==============================================================
    # SCREEN 3b: FORGOT PASSWORD  -  NFR4
    # ==============================================================
    def show_forgot_password_screen(self):
        self.clear_window()
        tk.Label(self.root, text="Forgot Password", font=("Arial", 16, "bold")).pack(pady=20)
        tk.Label(self.root, text="Enter your username and registered email.\nIf they match, you can set a new password.",
                 font=("Arial", 9), fg="#444444", justify="center").pack(pady=(0, 10))

        form = tk.Frame(self.root)
        form.pack()

        tk.Label(form, text="Username:").grid(row=0, column=0, sticky="e", padx=5, pady=6)
        username_entry = tk.Entry(form, width=30)
        username_entry.grid(row=0, column=1, pady=6)

        tk.Label(form, text="Registered Email:").grid(row=1, column=0, sticky="e", padx=5, pady=6)
        email_entry = tk.Entry(form, width=30)
        email_entry.grid(row=1, column=1, pady=6)

        tk.Label(form, text="New Password:").grid(row=2, column=0, sticky="e", padx=5, pady=6)
        new_password_entry = tk.Entry(form, width=30, show="*")
        new_password_entry.grid(row=2, column=1, pady=6)

        tk.Label(form, text="Confirm New Password:").grid(row=3, column=0, sticky="e", padx=5, pady=6)
        confirm_entry = tk.Entry(form, width=30, show="*")
        confirm_entry.grid(row=3, column=1, pady=6)

        def do_reset():
            if new_password_entry.get() != confirm_entry.get():
                messagebox.showerror("Error", "The two passwords do not match.")
                return
            success, message = Guest().reset_password(
                username_entry.get(), email_entry.get(), new_password_entry.get()
            )
            if success:
                messagebox.showinfo("Success", message)
                self.show_login_screen()
            else:
                messagebox.showerror("Error", message)

        tk.Button(self.root, text="Reset Password", width=20, command=do_reset).pack(pady=15)
        tk.Button(self.root, text="Back to Login", command=self.show_login_screen).pack()

    # ==============================================================
    # SCREEN 4: USER MAIN SCREEN  -  FR4-FR16
    # ==============================================================
    def show_user_screen(self):
        self.clear_window()
        self.selected_contact_id = None

        top = tk.Frame(self.root)
        top.pack(fill="x", padx=10, pady=8)
        tk.Label(top, text=f"Logged in as: {self.current_user.username} (User)",
                 font=("Arial", 11, "bold")).pack(side="left")
        tk.Button(top, text="Logout", command=self.show_guest_screen).pack(side="right")

        # ---- Search bar ----
        search_frame = tk.Frame(self.root)
        search_frame.pack(fill="x", padx=10)
        tk.Label(search_frame, text="Search:").pack(side="left")
        self.search_entry = tk.Entry(search_frame, width=30)
        self.search_entry.pack(side="left", padx=5)
        tk.Button(search_frame, text="Search", command=self.refresh_contact_table).pack(side="left")
        tk.Button(search_frame, text="Show All", command=lambda: (self.search_entry.delete(0, tk.END), self.refresh_contact_table())).pack(side="left", padx=5)

        # ---- Contact table ----
        table_frame = tk.Frame(self.root)
        table_frame.pack(padx=10, pady=8, fill="both", expand=True)

        self.contact_table = ttk.Treeview(
            table_frame, columns=("name", "phone", "email", "group", "fav"), show="headings", height=12
        )
        for col, label, width in [("name", "Full Name", 160), ("phone", "Phone", 110),
                                   ("email", "Email", 170), ("group", "Group", 90), ("fav", "Favorite", 70)]:
            self.contact_table.heading(col, text=label)
            self.contact_table.column(col, width=width)
        self.contact_table.pack(side="left", fill="both", expand=True)
        self.contact_table.bind("<<TreeviewSelect>>", self.on_contact_selected)

        # ---- Action buttons ----
        btn_frame = tk.Frame(self.root)
        btn_frame.pack(pady=8)
        tk.Button(btn_frame, text="Add Contact", width=14, command=self.open_add_contact_form).grid(row=0, column=0, padx=4)
        tk.Button(btn_frame, text="Edit Contact", width=14, command=self.open_edit_contact_form).grid(row=0, column=1, padx=4)
        tk.Button(btn_frame, text="Delete Contact", width=14, command=self.delete_selected_contact).grid(row=0, column=2, padx=4)
        tk.Button(btn_frame, text="Mark Favorite", width=14, command=self.toggle_favorite_selected).grid(row=0, column=3, padx=4)
        tk.Button(btn_frame, text="Manage Groups", width=14, command=self.open_groups_window).grid(row=0, column=4, padx=4)
        tk.Button(btn_frame, text="Import CSV", width=12, command=self.do_import_csv).grid(row=0, column=5, padx=4)
        tk.Button(btn_frame, text="Export CSV", width=12, command=self.do_export_csv).grid(row=0, column=6, padx=4)

        self.refresh_contact_table()

    def refresh_contact_table(self):
        keyword = self.search_entry.get().strip()
        if keyword:
            contacts = self.current_user.search_contact(keyword)
        else:
            contacts = self.current_user.view_contact_list()

        for row in self.contact_table.get_children():
            self.contact_table.delete(row)

        for c in contacts:
            self.contact_table.insert(
                "", "end", iid=c["contact_id"],
                values=(c["full_name"], c["phone_number"], c["email"] or "",
                        c["group_name"] or "-", "Yes" if c["is_favorite"] else "No"),
            )

    def on_contact_selected(self, event):
        selection = self.contact_table.selection()
        self.selected_contact_id = int(selection[0]) if selection else None

    def toggle_favorite_selected(self):
        if not self.selected_contact_id:
            messagebox.showwarning("No selection", "Please select a contact first.")
            return
        self.current_user.mark_favorite(self.selected_contact_id)
        self.refresh_contact_table()

    def delete_selected_contact(self):
        if not self.selected_contact_id:
            messagebox.showwarning("No selection", "Please select a contact first.")
            return
        if messagebox.askyesno("Confirm", "Delete this contact?"):
            self.current_user.delete_contact(self.selected_contact_id)
            self.selected_contact_id = None
            self.refresh_contact_table()

    def do_export_csv(self):
        filepath = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
        if filepath:
            count = self.current_user.export_contact(filepath)
            messagebox.showinfo("Export complete", f"Exported {count} contact(s).")

    def do_import_csv(self):
        filepath = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if filepath:
            imported, skipped = self.current_user.import_contact(filepath)
            messagebox.showinfo("Import complete", f"Imported: {imported}, Skipped: {skipped}")
            self.refresh_contact_table()

    # ---- Add / Edit contact form (a separate small window) ----
    def open_add_contact_form(self):
        self._open_contact_form(editing=False)

    def open_edit_contact_form(self):
        if not self.selected_contact_id:
            messagebox.showwarning("No selection", "Please select a contact first.")
            return
        self._open_contact_form(editing=True)

    def _open_contact_form(self, editing):
        existing = None
        if editing:
            for c in self.current_user.view_contact_list():
                if c["contact_id"] == self.selected_contact_id:
                    existing = c
                    break

        window = tk.Toplevel(self.root)
        window.title("Edit Contact" if editing else "Add Contact")
        window.geometry("350x380")

        fields = {}
        labels = ["Full Name", "Phone Number", "Email", "Address", "Note"]
        keys = ["full_name", "phone_number", "email", "address", "note"]
        for i, (label, key) in enumerate(zip(labels, keys)):
            tk.Label(window, text=label + ":").pack(pady=(10 if i == 0 else 4, 0))
            entry = tk.Entry(window, width=35)
            if existing:
                entry.insert(0, existing[key] or "")
            entry.pack()
            fields[key] = entry

        tk.Label(window, text="Group:").pack(pady=(4, 0))
        groups = self.current_user.view_group()
        group_names = ["(No group)"] + [g["group_name"] for g in groups]
        group_var = tk.StringVar(value="(No group)")
        if existing and existing["group_name"]:
            group_var.set(existing["group_name"])
        group_dropdown = ttk.Combobox(window, textvariable=group_var, values=group_names, state="readonly", width=32)
        group_dropdown.pack()

        def save():
            selected_group_id = None
            if group_var.get() != "(No group)":
                for g in groups:
                    if g["group_name"] == group_var.get():
                        selected_group_id = g["group_id"]

            values = {k: e.get() for k, e in fields.items()}

            if editing:
                success, message = self.current_user.edit_contact(
                    self.selected_contact_id, values["full_name"], values["phone_number"],
                    values["email"], values["address"], values["note"], selected_group_id,
                )
            else:
                success, message = self.current_user.add_contact(
                    values["full_name"], values["phone_number"], values["email"],
                    values["address"], values["note"], selected_group_id,
                )

            if success:
                window.destroy()
                self.refresh_contact_table()
            else:
                messagebox.showerror("Error", message)

        tk.Button(window, text="Save", width=15, command=save).pack(pady=15)

    # ---- Manage Groups window ----
    def open_groups_window(self):
        window = tk.Toplevel(self.root)
        window.title("Manage Groups")
        window.geometry("320x350")

        listbox = tk.Listbox(window, width=35, height=10)
        listbox.pack(pady=10)

        def refresh_list():
            listbox.delete(0, tk.END)
            for g in self.current_user.view_group():
                listbox.insert(tk.END, g["group_name"])

        refresh_list()

        def get_selected_group():
            selection = listbox.curselection()
            if not selection:
                return None
            groups = self.current_user.view_group()
            return groups[selection[0]]

        def add_group():
            name = simpledialog.askstring("New Group", "Group name:")
            if name:
                success, message = self.current_user.create_group(name)
                if not success:
                    messagebox.showerror("Error", message)
                refresh_list()

        def edit_group():
            group = get_selected_group()
            if not group:
                messagebox.showwarning("No selection", "Please select a group first.")
                return
            new_name = simpledialog.askstring("Edit Group", "New name:", initialvalue=group["group_name"])
            if new_name:
                self.current_user.edit_group(group["group_id"], new_name)
                refresh_list()

        def delete_group():
            group = get_selected_group()
            if not group:
                messagebox.showwarning("No selection", "Please select a group first.")
                return
            if messagebox.askyesno("Confirm", f'Delete group "{group["group_name"]}"?\nContacts inside will be kept, just unassigned.'):
                self.current_user.delete_group(group["group_id"])
                refresh_list()
                self.refresh_contact_table()

        btns = tk.Frame(window)
        btns.pack(pady=10)
        tk.Button(btns, text="Add", width=8, command=add_group).grid(row=0, column=0, padx=4)
        tk.Button(btns, text="Edit", width=8, command=edit_group).grid(row=0, column=1, padx=4)
        tk.Button(btns, text="Delete", width=8, command=delete_group).grid(row=0, column=2, padx=4)

    # ==============================================================
    # NOTE: the Admin screen (show_admin_screen) is a SEPARATE part of
    # the project, built by another team member. This placeholder just
    # prevents a crash if someone logs in with the admin account while
    # testing this file on its own.
    # ==============================================================
    def show_admin_screen(self):
        self.clear_window()
        tk.Label(self.root, text="Admin Dashboard", font=("Arial", 16, "bold")).pack(pady=30)
        tk.Label(self.root, text=f"Logged in as: {self.current_user.username} (Admin)").pack()
        tk.Label(self.root, text="(The Admin screen is implemented in a separate file\nby another team member.)",
                 fg="gray").pack(pady=20)
        tk.Button(self.root, text="Logout", command=self.show_guest_screen).pack()


if __name__ == "__main__":
    create_tables()  # make sure the database and tables exist before we start

    root = tk.Tk()
    app = PhoneBookApp(root)
    root.mainloop()

