# Member 4 — Graphical Interface: Guest / Login / Register / User Screens

This package contains the part of the Tkinter interface assigned to
**Member 4**: everything a Guest or a regular User sees and interacts with.
The Admin dashboard is a separate part of the project, built by Member 5.

## What is included in `main.py`

| Screen | What it does | Related Requirement |
|---|---|---|
| Guest screen | Entry screen with 3 options: View Demo Contacts, Register, Login | FR1, FR2, FR3 |
| View Demo Contacts | Shows 3 fixed sample contacts (read-only) | FR2 |
| Register screen | Create a new account | FR1 |
| Login screen | Sign in with username/password | FR3 |
| Forgot Password screen | Reset password using username + registered email | NFR4 |
| User main screen | Contact list (Treeview), search bar, Add/Edit/Delete/Favorite/Import/Export buttons | FR4-FR8, FR10, FR15, FR16 |
| Add/Edit Contact form | Pop-up window to enter contact details | FR4, FR7 |
| Manage Groups window | Add/Edit/Delete contact groups | FR9, FR11-FR14 |

A small placeholder `show_admin_screen()` is included so the program does not
crash if someone logs in with the admin account while testing this file on
its own — the real Admin screen lives in Member 5's file.

## How to run

```bash
python3 main.py
```

A default Admin account (`admin` / `admin123`) already exists so you can
confirm the placeholder screen appears correctly, but the main purpose of
this file is the Guest/User experience.

## Folder structure

```
main.py               <- Member 4's screens (this is the file to review)
models/
├── database.py        <- shared: connects to SQLite
├── guest.py            <- shared: Guest class (Member 1's part)
├── user.py              <- shared: User class (Member 1's part)
├── admin.py              <- shared: Admin class (only used for the placeholder)
├── contact.py             <- shared: Contact class (Member's part for CRUD)
└── group.py                <- shared: Group class
```

The `models/` files are included only so this package can run on its own for
testing/demo purposes — they were built collaboratively with other members,
not written by Member 4.
