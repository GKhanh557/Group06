"""
admin.py

The Admin class represents the system administrator.
Admin INHERITS from User (Admin "is a" User who also has extra permissions) -
this matches the generalization arrow in the Class Diagram.

Admin does NOT have its own database table - it uses the SAME "User" table,
just with role = 'admin'. This is why Admin and User share the same __init__.
"""

from models.user import User
from models.database import get_connection


class Admin(User):

    def manage_user_accounts(self):
        """FR17: view the list of all normal User accounts (not other Admins)."""
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT user_id, username, email, is_locked FROM User WHERE role = 'user' ORDER BY username"
        )
        rows = cursor.fetchall()
        conn.close()
        return rows

    def search_user_accounts(self, keyword):
        """FR17: search User accounts by username or email (used by the Search box)."""
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """SELECT user_id, username, email, is_locked FROM User
               WHERE role = 'user' AND (username LIKE ? OR email LIKE ?)
               ORDER BY username""",
            ("%" + keyword + "%", "%" + keyword + "%"),
        )
        rows = cursor.fetchall()
        conn.close()
        return rows

    def add_user(self, username, password, email):
        """FR17: Admin creates a new User account directly (e.g. for staff)."""
        from models.database import hash_password

        username = username.strip()
        if username == "" or password.strip() == "":
            return False, "Username and password cannot be empty."

        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM User WHERE username = ?", (username,))
        if cursor.fetchone() is not None:
            conn.close()
            return False, "This username already exists."

        cursor.execute(
            "INSERT INTO User (username, password, email, role) VALUES (?, ?, ?, 'user')",
            (username, hash_password(password), email),
        )
        new_user_id = cursor.lastrowid
        for group_name in ["Personal", "Work", "Family", "Other"]:
            cursor.execute(
                "INSERT INTO Groups (group_name, user_id) VALUES (?, ?)",
                (group_name, new_user_id),
            )
        conn.commit()
        conn.close()
        return True, "User account created successfully."

    def edit_user(self, target_user_id, username, email):
        """FR17: Admin edits a User's username/email."""
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE User SET username = ?, email = ? WHERE user_id = ? AND role = 'user'",
            (username.strip(), email.strip(), target_user_id),
        )
        conn.commit()
        updated = cursor.rowcount > 0
        conn.close()
        return updated

    def delete_user(self, target_user_id):
        """FR17: Admin permanently deletes a User account (and their contacts/groups)."""
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM Contact WHERE user_id = ?", (target_user_id,))
        cursor.execute("DELETE FROM Groups WHERE user_id = ?", (target_user_id,))
        cursor.execute("DELETE FROM User WHERE user_id = ? AND role = 'user'", (target_user_id,))
        conn.commit()
        deleted = cursor.rowcount > 0
        conn.close()
        return deleted

    def lock_account(self, target_user_id):
        """FR18"""
        return self._set_lock_status(target_user_id, locked=1)

    def unlock_account(self, target_user_id):
        """FR19"""
        return self._set_lock_status(target_user_id, locked=0)

    def _set_lock_status(self, target_user_id, locked):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE User SET is_locked = ? WHERE user_id = ? AND role = 'user'",
            (locked, target_user_id),
        )
        conn.commit()
        changed = cursor.rowcount > 0
        conn.close()
        return changed

    def view_system_statistics(self):
        """FR20: count of users, contacts, and groups across the WHOLE system."""
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT COUNT(*) AS total FROM User WHERE role = 'user'")
        total_users = cursor.fetchone()["total"]

        cursor.execute("SELECT COUNT(*) AS total FROM Contact")
        total_contacts = cursor.fetchone()["total"]

        cursor.execute("SELECT COUNT(*) AS total FROM Groups")
        total_groups = cursor.fetchone()["total"]

        conn.close()
        return {
            "total_users": total_users,
            "total_contacts": total_contacts,
            "total_groups": total_groups,
        }
